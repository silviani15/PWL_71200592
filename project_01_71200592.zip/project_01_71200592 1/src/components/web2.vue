<template>
    <div class="hello">
      <div class="geser">
        <h3>Daftar Menu</h3>
        <a class="link" role="link" href="web2.vue" @click="openInNewTab('web2.vue')">Makanan</a>
          <p>Minuman</p>
          <p>Snack</p>
          
      </div>
      <div class="box1"></div>
      <div>
        <div class="box2"></div>
      </div>
      <div class="check">
        <a class="link1" role="link" href="web2.vue" @click="openInNewTab('web2.vue')">Checkout</a>
      </div>
    </div>
    <router-view></router-view>
  </template>
  
  <script>
  export default {
    name: 'web2'
}
  </script>
  
  <!-- Add "scoped" attribute to limit CSS to this component only -->
  <style scoped>
  .hello {
    margin: 40px 0 0;
    text-align: left;
  }
  h3 {
    font-size: medium;
  }
  .link{
    color: white;
    text-decoration: none;
  }
  .link1{
    color: black;
    text-decoration: none;
    font-weight: bold;
  }
  .check{
    color: black;
    font-weight: bold;
    padding-left: 80px;
    margin: -35px 0 0;
    border-radius: 95px;
  }
  .geser{
    padding-left: 50px;
    color: white;
  }
  .box1{
    width:250px;
    height:1063px;
    margin-top: -500px;
    margin-left: -15px;
    background:#ff6781;
    }
  .box2{
    background: yellow;
    width:200px;
    height:50px;
    margin-top: -80px;
    margin-left: 15px;
  }
  </style>
  