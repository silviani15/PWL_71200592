import { createRouter, createWebHistory } from 'vue-router'
import web2 from '../components/web2.vue'

const router = createRouter({
    history: createWebHistory(process.env.BASE_URL),
    routes
  })
  
  export default router